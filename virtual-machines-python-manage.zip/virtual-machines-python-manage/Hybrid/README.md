---
services: virtual-machines
platforms: python
author: viananth
---

# Azure Stack Virtual Machines Management Samples - Python

This sample has moved to https://github.com/Azure-Samples/Hybrid-Compute-Python-Manage-VM

---

This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/). For more information see the [Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/) or contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any additional questions or comments.

